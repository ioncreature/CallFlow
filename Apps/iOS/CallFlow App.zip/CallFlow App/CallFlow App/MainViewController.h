//
//  MainViewController.h
//  CallFlow App
//
//  Created by peter.yakovlev on 5/3/13.
//  Copyright (c) 2013 peter.yakovlev. All rights reserved.
//

#import "FlipsideViewController.h"

@interface MainViewController : UIViewController <FlipsideViewControllerDelegate>
{
    IBOutlet UIWebView *myWebView;

}


- (IBAction)showInfo:(id)sender;

@property (nonatomic, retain) UIWebView *webView;

@end
